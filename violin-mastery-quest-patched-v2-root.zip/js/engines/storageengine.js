// js/engines/storageengine.js
// Legacy compatibility shim: route old imports to the canonical storage module.
export * from './storage.js';
export { default } from '../config/storage.js';